<?php

include("ConnectDB.php");

$id=$_GET['id'];

if(mysqli_query($con,"delete  FROM person where id =2"))
header('Location: index.php');
else
echo  "delete  FROM person where id =$id";
?>
