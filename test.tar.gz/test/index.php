<html>
<head>
	<title>CRUD: CReate, Update, Delete PHP MySQL</title>
	<link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>


<?php

include("ConnectDB.php");
$Action="insert";
$text="insert";
$page="insert.php";
$class ="btn";
include("temple.php");
include("select.php");
?>



</body>
</html>

