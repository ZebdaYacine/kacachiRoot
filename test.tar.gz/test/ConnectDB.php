<?php

$con=mysqli_connect("127.0.0.1","zebda","","zebda_db_test");

if (mysqli_connect_errno($con)){
  echo "Failed to connect to MySQL: " . mysqli_connect_error();
}

?>
