<?php

include("ConnectDB.php");


$sql="INSERT INTO person VALUES('$_POST[name]','$_POST[email]',15)";

echo $sql;

if (!mysqli_query($con,$sql))
  {
  die('Error: ' . mysqli_error($con));
  }

header("Location: index.php");





?>
