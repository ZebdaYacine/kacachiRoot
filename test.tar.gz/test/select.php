

<table>

<thead>
        <tr>
        <th>Name </th>
        <th>Email</th>
        <th>Action</th>
        </tr>
</thead>


<?php
$result = mysqli_query($con,"SELECT * FROM person");

while($row = mysqli_fetch_array($result))
  {
	$id=$row['id'];
  echo "<tr>
	<td>".$row['name']."</td>
	<td>".$row['email']."</td>
	<td><a href='update.php?id=$id' class='edit_btn'>Edit</a></td>
        <td><a href='delete.php?id=$id' class='del_btn'>Delete</a></td>
	</tr>";
  }

?>

</table>

