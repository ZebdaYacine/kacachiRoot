<html>
<head>
	<title>CRUD: CReate, Update, Delete PHP MySQL</title>
	<link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>


<?php

include("ConnectDB.php");
$Action="update";
$text="update";
$page="update.php";
$class ="btn1";
include("temple.php");
include("select.php");
if (isset($_POST['update'])) {
        $name = $_POST['name'];
        $email = $_POST['email'];
        $id =$_POST['id']; 
        $test=mysqli_query($con, "update  person set name ='$name',email ='$email' where id = $id"); 
        if($test)
	header('location: index.php');
	else
	echo mysql_error($conn);
	echo "update  person set name ='$name',email ='$email' where id = $id";
}


?>



</body>
</html>

