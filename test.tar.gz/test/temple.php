<?php
include('ConnectDB.php');
$id=$_GET['id'];

$result = mysqli_query($con,"SELECT * FROM person where id=".$id);
$row = mysqli_fetch_array($result);

$name=$row['name'];
$email=$row['email'];

?>

<form method="post" action="<?php echo $page;?>" >
                <div class="input-group">
                        <label>Name</label>
                        <input type="text" name="name" value="<?php echo $name; ?>">
                </div>
                <div class="input-group">
                        <label>email</label>
                        <input type="email" name="email" value="<?php echo $email;  ?>">
                </div>
                <input type="hidden" name="id" value="<?php echo $id; ?>">
                <div class="input-group">
                                <button class="<?php echo $class;?>" type="submit" name="<?php echo $Action;?>">
					<?php echo $text;?></button>
                </div>
</form>

