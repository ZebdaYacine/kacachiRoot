<?php

session_start();


$servername = "127.0.0.1";
$username = "zebda";
$password = "";
$dbname = "zebda_db_test";

$conn = new mysqli($servername, $username, $password,$dbname);

if ($conn->connect_error) 
die("Connection failed: " . $conn->connect_error);


if (isset($_POST['Update'])) {
        $name = $_POST['name'];
        $email = $_POST['email'];
        $id =$_POST['id']; 
        $test=mysqli_query($conn, "update  person set name ='$name',email ='$email' where id = $id "); 
       	echo "update  person set name ='$name',email ='$email' where id = $id ";
	if ($test) {
        $_SESSION['message'] = "Record updated"; 
        header('location: index.php');
        }
        echo "name :".$name ." email :". $email ."INSERT INTO person (name,email) VALUES ('$name', '$email')";
}



if (isset($_POST['save'])) {
	$name = $_POST['name'];
	$email = $_POST['email'];
	$test=mysqli_query($conn, "INSERT INTO person (name,email) VALUES ('$name', '$email')"); 
	if ($test) {
	$_SESSION['message'] = "Record saved"; 
	header('location: index.php');
	}
	echo "name :".$name ." email :". $email ."INSERT INTO person (name,email) VALUES ('$name', '$email')";
}

else if(isset($_GET['del'])){
        $id=$_GET['del'];
        mysqli_query($conn, "delete  FROM person where id = '$id'");
        echo  "delete  FROM person where name= $name";
	$_SESSION['message'] = "record deleted!"; 
	header('location: index.php');
}




?>
