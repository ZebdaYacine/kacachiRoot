<html>
<head>
	<title>CRUD: CReate, Update, Delete PHP MySQL</title>
	<link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
<?php

	$name=$_GET['name'];
	$email=$_GET['email'];
	$id =$_GET['id'];
?>
	<form method="post" action="server.php" >
		<div class="input-group">
			<label>Name</label>
			<input type="text" name="name" value="<?php echo $name; ?>">
		</div>
		<div class="input-group">
			<label>email</label>
			<input type="email" name="email" value="<?php echo $email;  ?>">
		</div>
		<input type="hidden" name="id" value="<?php echo $id; ?>">
		<div class="input-group">
			<?php if ($id !=""): ?>
				<button class="btn1" type="submit" name="Update">update</button>
			<?php else: ?>
				<button class="btn" type="submit" name="save" >Save</button>
			<?php endif ?>
		</div>
	</form>


<?php  include('server.php'); ?>
<?php if (isset($_SESSION['message'])): ?>
	<div class="msg">
		<?php 
			echo $_SESSION['message']; 
			unset($_SESSION['message']);
		?>
	</div>
<?php endif ?>

<?php $results = mysqli_query($conn, "SELECT * FROM person"); ?>

<table>
	<thead>
		<tr>
			<th>Name</th>
			<th>Email</th>
			<th colspan="2">Action</th>
		</tr>
	</thead>
	
	<?php while ($row = mysqli_fetch_array($results)) { ?>
		<tr>
			<td><?php echo $row['name']; ?></td>
			<td><?php echo $row['email']; ?></td>
			<td>
		<a href="index.php?id=<?php echo $row['id'];?>&name=<?php echo $row['name'];?>&email=<?php echo $row['email'];?>" class="edit_btn" >Edit</a>
			</td>
			<td>
				<a href="server.php?del=<?php echo $row['id']; ?>" class="del_btn">Delete</a>
			</td>
		</tr>
	<?php } ?>
</table>


</body>
</html>

